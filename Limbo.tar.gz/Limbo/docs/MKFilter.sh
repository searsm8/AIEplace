##
# @file   MKFilter.sh
# @author Yibo Lin
# @date   Jan 2017
#
#!/bin/bash

sed -e 's|##|//!|' $1
#sed -e 's/##/\/\/!/' $1
