Limbo.Math {#Math}
---------

[TOC]

# Introduction {#Math_Introduction}

Some useful mathematical functions, such as compute the absolute value, compute the average of an array, etc. 

# References {#Math_References}

- [limbo/math/Math.h](@ref Math.h)
